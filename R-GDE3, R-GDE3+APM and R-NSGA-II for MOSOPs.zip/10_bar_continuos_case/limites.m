NumExec=1;
TamanhoPopulacao=50;
NumMaxGeracoes=10;
epsi_met=0.01;

DimEspa=10;
NumFO=2;
QuantRestr=10;
LimSup=40*ones(1,DimEspa);
LimInf=0.1*ones(1,DimEspa);

ProbCruzamento=0.9;
F=0.2;
PRef=[5060.85 2];
mum=100;
muc=2;
