These are the baseline source codes use (.m files) in the 
computational experiments of the manuscript entitled "Solving Multi-Objective 
Structural Optimization Problems Using GDE3 and NSGA-II with Reference Points".
Here is some information:

1) The codes were written in Brazilian Portuguese (variables and files names);

2) Use the file limites.m to define the parameters NumExec (num-
ber of independent runs); TamanhoPopulacao (population size); Num-
MaxGeracoes (total number of generations); epsi_met (epsilon value); 
PRef (the Reference Point); ProbCruzamento (CR
to R-GDE3+APM and R-GDE3 or CP to R-NSGA-II); F value to R-
GDE3+APM and R-GDE3; mum ($\eta_m$) and muc ($\eta_c$) to R-NSGA-II;

3) To execute the algorithm choose one of the R_GDE3.m, R_GDE3_APM.m or 
R_NSGAII.m files according to the algorithm and run it;

4) The files NDSM.m, RC.m, RC2.m are modification of the replace_chromosome.m and 
non_domination_sort_mod.m by Aravind Seshadri available in
NSGA - II: A multi-objective optimization algorithm 
https://www.mathworks.com/matlabcentral/fileexchange/10429-nsga-ii-a-multi-
objective-optimization-algorithm.

5) The code is programmed to solve the problem of the 10-bar continuos case.



