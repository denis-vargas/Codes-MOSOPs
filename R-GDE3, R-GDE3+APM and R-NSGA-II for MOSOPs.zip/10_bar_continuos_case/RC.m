function f  = RC(Populacao, NumFO, DimEspa,TamanhoPopulacao)

[N, m] = size(Populacao);
[temp,index] = sort(Populacao(:,NumFO + DimEspa + 1));
clear temp m
for i = 1 : N
    sorted_chromosome(i,:) = Populacao(index(i),:);
end
max_rank = max(Populacao(:,NumFO + DimEspa + 1));
previous_index = 0;
for i = 1 : max_rank
    current_index = max(find(sorted_chromosome(:,NumFO + DimEspa + 1) == i));
    if current_index > TamanhoPopulacao
        remaining = TamanhoPopulacao - previous_index;
        temp_TamanhoPopulacao = ...
            sorted_chromosome(previous_index + 1 : current_index, :);
        [temp_sort,temp_sort_index] = ...
            sort(temp_TamanhoPopulacao(:, NumFO + DimEspa + 2),'descend');
        CoZe1=0;
        for j = 1 : remaining
            if temp_TamanhoPopulacao(temp_sort_index(j),NumFO + DimEspa + 2)~=0
                f(previous_index + j,:) = temp_TamanhoPopulacao(temp_sort_index(j),:);
                CoZe1=CoZe1+1;
            end
        end
        remaining2=remaining-CoZe1;
        if remaining2~=0
            AcuMTP=[];
            for CoZe2=1:size(temp_TamanhoPopulacao,1)
                if temp_TamanhoPopulacao(CoZe2,NumFO + DimEspa + 2)==0
                    AcuMTP=[AcuMTP;temp_TamanhoPopulacao(CoZe2,:)];
                end
            end
            ELSor=randperm(size(AcuMTP,1));
            for j = 1 : remaining2
                f(size(f,1) + 1,:) = AcuMTP(ELSor(j),:);
            end
        end
        return;
    elseif current_index < TamanhoPopulacao
        f(previous_index + 1 : current_index, :) = ...
            sorted_chromosome(previous_index + 1 : current_index, :);
    else
        f(previous_index + 1 : current_index, :) = ...
            sorted_chromosome(previous_index + 1 : current_index, :);
        return;
    end
    previous_index = current_index;
end
