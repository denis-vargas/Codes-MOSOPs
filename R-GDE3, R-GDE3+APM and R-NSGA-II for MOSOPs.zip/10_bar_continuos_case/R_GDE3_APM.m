tic
clear all
format long
clc
contarodada=1;
limites;


%tic
while contarodada<=NumExec
rand('state',contarodada);

% Principal 
clc

% Par�mentros Iniciais

limites;
NumGeracoes=1;
ContaFilhos=1;
for NumPopIni=1:TamanhoPopulacao
    for NumDimEspa=1:DimEspa
        Populacao(NumPopIni,NumDimEspa)=LimInf(1,NumDimEspa)+rand()*...
            (LimSup(1,NumDimEspa)-LimInf(1,NumDimEspa));
    end
end
zeroscompara=zeros(1,QuantRestr);
ArquExt=[];

ArqInput_C;
for i33=1:TamanhoPopulacao
    area{i33}=Populacao(i33,:);
    [Desl2{i33},Tens{i33}]=Trelica_3d(nBarras,area{i33},numNodes,numColnodesCoord,nodesCoordVetor,...
        CVetor,nodesC,nodesL,numConst,elasticity);    
    Desl{i33}=trans_vet_mat(Desl2{i33},numNodes);
end
clear area Desl2;


% Calculando Fun��o da Popula��o
clear i;
Populacao222=Populacao;
for i=1:TamanhoPopulacao    
    Populacao22a(i,:)=funcpop(Populacao222(i,:),Desl{i});
end
Populacao=[Populacao222 Populacao22a];
clear Populacao222 Populacao22a; 

% Calculando as Viola��es das Restri��es pela Popula��o

clear i;
for i=1:TamanhoPopulacao
    Populacao(i,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))=restricao(Tens{i},QuantRestr);
end

SolMono=[];
% Iniciando a ED
while (NumGeracoes<=NumMaxGeracoes) 
   
GuardaPop=Populacao;
mediaaptsom=sum(Populacao(:,(DimEspa+1):(DimEspa+NumFO)));
mediaapt=mediaaptsom./TamanhoPopulacao;

% Calculo do Kj

somaviolacao=sum(Populacao(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr)));
mediaviolacao=somaviolacao./TamanhoPopulacao;
mediaviolacaoquad=mediaviolacao.*mediaviolacao;
sd2mediaviolacao1=sum(mediaviolacaoquad);
if sd2mediaviolacao1==0
    sd2mediaviolacao1=1;
end
clear i;
for i=1:QuantRestr
    Kj(i,:)=abs(mediaapt)*mediaviolacao(1,i)/sd2mediaviolacao1;
end

% Aptid�o

clear i i2;
for i=1:TamanhoPopulacao
    if isequal(Populacao(i,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr)),zeros(1,QuantRestr))==0
        for i2=1:NumFO
            if Populacao(i,DimEspa+i2)<=mediaapt(i2)
                Populacao(i,DimEspa+i2)=mediaapt(i2)+(Populacao(i...
                ,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))*Kj(:,i2));
            else
                Populacao(i,DimEspa+i2)=Populacao(i,DimEspa+i2)+...
                    (Populacao(i,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))*Kj(:,i2));
            end
        end
    end
end

filhos=[];
for ContaFilhos=1:TamanhoPopulacao
    [vetexper22{ContaFilhos},DeslVE22{ContaFilhos},TensVE22{ContaFilhos}]=ContFil(Populacao,ContaFilhos);
end

ContaFilhos=1;

while ContaFilhos<=TamanhoPopulacao

vetalvo=Populacao(ContaFilhos,:);    
vetexper=vetexper22{ContaFilhos};
DeslVE=DeslVE22{ContaFilhos};
TensVE=TensVE22{ContaFilhos};
GuardaPop=[GuardaPop;vetexper];    
    
% Calculando a Aptid�o do Vetor Experimental
clear i2;
if isequal(vetexper(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr)),zeros(1,QuantRestr))==0
    for i2=1:NumFO
        if vetexper(:,DimEspa+i2)<=mediaapt(i2)
            vetexper(:,DimEspa+i2)=mediaapt(i2)+(vetexper(:...
            ,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))*Kj(:,i2));
        else
            vetexper(:,DimEspa+i2)=vetexper(:,DimEspa+i2)+...
                (vetexper(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))*Kj(:,i2));
        end
    end
end

if isequal(vetexper(:,DimEspa+1:DimEspa+NumFO),vetalvo(:,DimEspa+1:DimEspa+NumFO))==0
    if verificavetormenor(vetexper(:,DimEspa+1:DimEspa+NumFO),vetalvo(:,DimEspa+1:DimEspa+NumFO))==1
        filhos=[filhos;vetexper];
    else
        if verificavetormenor(vetalvo(:,DimEspa+1:DimEspa+NumFO),vetexper(:,DimEspa+1:DimEspa+NumFO))==1
            filhos=[filhos;vetalvo];
        else
            filhos=[filhos;vetalvo;vetexper];
        end
    end
else
    filhos=[filhos;vetalvo;vetexper];
end
ContaFilhos=ContaFilhos+1;
%FIM Comparando com o Vetor Alvo
clear vetexper3 vetexper2 vetexper DeslVE TensVE;
end

filhos=excluieleig(filhos);
Populacao=[];
Populacao=filhos;

Populacao=NDSM(Populacao, NumFO, DimEspa);
Populacao=RC2(Populacao, NumFO, DimEspa, TamanhoPopulacao,PRef,epsi_met);    

% Volta com valores originais das fun��es (sem penaliza��o)
Populacao(:,(DimEspa+NumFO+1):(DimEspa+NumFO+2))=[];

for i=1:TamanhoPopulacao
    LinhCar=verquallin(Populacao(i,1:DimEspa),GuardaPop(:,1:DimEspa));
    PopulacaoLinhCar(i,:)=GuardaPop(LinhCar,:);
end

Populacao=[];
Populacao=PopulacaoLinhCar;
clear PopulacaoLinhCar;

%ATUALIZA ARQUIVO EXTERNO


% pega fact�veis da Popula��o
PopulacaoFac=[];
CPF1=1;
for i=1:TamanhoPopulacao
    if isequal(Populacao(i,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr), zeros(1,QuantRestr))==1;
        PopulacaoFac(CPF1,:)=Populacao(i,1:DimEspa+NumFO);
        CPF1=CPF1+1;
    end
end
%FIM DE pega fact�veis da Popula��o

if isempty(PopulacaoFac)==0

ArquExt=[ArquExt;PopulacaoFac];
CArquExt1=ArquExt(:,DimEspa+1);
CArquExt2=ArquExt(:,DimEspa+2);
ParetoFr=paretofront([CArquExt1 CArquExt2]);
ArquExt=excluieleig(ArquExt(ParetoFr,:));
    
end


% Atualiza Populacao e Gera��o
ContaFilhos=1;
clc
fprintf('\n');
fprintf('R-GDE3+APM\n');
fprintf('Execucao %d\n',contarodada);
fprintf('Geracao %d\n',NumGeracoes);
NumGeracoes=NumGeracoes+1;

clear LinhCar                   Selecaovet3               mediaaptsom      ArquExt1...                  
      NumDimEspa                Selecaovetalvo            mediaviolacao    ArquExt2...
      mediaviolacaoquad         ArquExt3                  opcoesdeescolha  CPF1...
      contavetexp               sd2mediaviolacao1         ConjuntoParetoOtimoTotal  erre...
      somaviolacao              vet1                      filhos                    vet2...                      
      PopulacaoFac              vet3                      i                         vetalvo...
      idlim                     vetexper                  Selecaovet1               jh...
      vetordoad                 Selecaovet2               mediaapt                  GuardaPop;

end

CArquExt1=ArquExt(:,DimEspa+1);
CArquExt2=ArquExt(:,DimEspa+2);
ParetoFr=paretofront([CArquExt1 CArquExt2]);
ArquExt2=[];
ArquExt2=ArquExt(ParetoFr,:);
clear ArquExt;
ArquExt=ArquExt2;
clear ArquExt2;
Rodada{contarodada}=[ArquExt(:,1:DimEspa) ArquExt(:,DimEspa+1:DimEspa+NumFO)];
Rodada{contarodada}=excluieleig(Rodada{contarodada});
contarodada=contarodada+1;
clear Populacao ArquExt;
clear CArquExt1 CArquExt2 ParetoFr;

end

resultados=strcat('R_GDE3_APM.mat');
save(resultados,'Rodada');
toc