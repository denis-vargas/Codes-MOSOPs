function Populacao  = RC2(Populacao, NumFO, DimEspa, TamanhoPopulacao, PRef,epsi_met)

Populacao(:,NumFO+DimEspa+2)=[];
if Populacao(TamanhoPopulacao+1,NumFO+DimEspa+1)>Populacao(TamanhoPopulacao,NumFO+DimEspa+1)
    Populacao=Populacao(1:TamanhoPopulacao,:);    
else             
    [Populacao_UltRank_p,Q_i]=Tira_Rank(Populacao,NumFO,DimEspa,TamanhoPopulacao);
    for CMaioX=1:NumFO
        MaioX(CMaioX)=max(Populacao(:,DimEspa + CMaioX));
        MenoX(CMaioX)=min(Populacao(:,DimEspa + CMaioX));
    end    
    Populacao=Populacao(1:TamanhoPopulacao-Q_i,:);
    Populacao_UltRank_Res2=[];
    while size(Populacao,1)<TamanhoPopulacao
        if isempty(Populacao_UltRank_p)==1
            while size(Populacao,1)<TamanhoPopulacao
                Pos_Esc=randperm(size(Populacao_UltRank_Res2,1));
                Populacao=[Populacao;Populacao_UltRank_Res2(Pos_Esc(1),:)];
                Populacao_UltRank_Res2(Pos_Esc(1),:)=[];
            end
        else
            [Ele_Ent,Populacao_UltRank_p,Populacao_UltRank_Res]=recalque_certo...
            (Populacao_UltRank_p, NumFO, DimEspa,PRef,epsi_met,MaioX,MenoX);    
            Populacao=[Populacao;Ele_Ent];
            Populacao_UltRank_Res2=[Populacao_UltRank_Res2;Populacao_UltRank_Res];
            clear Ele_Ent Populacao_UltRank_Res;            
        end        
    end    
end
Populacao=[Populacao zeros(size(Populacao,1),1)];