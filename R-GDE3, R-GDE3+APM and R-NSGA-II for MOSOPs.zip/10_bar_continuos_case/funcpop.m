function result5444=funcpop(n4,desl1);

Eles=[360 360 360 360 360 360 360*sqrt(2) 360*sqrt(2) 360*sqrt(2) 360*sqrt(2)];

result5444(1,1)=0.1*(n4*Eles');

result5444(1,2)=max(max(abs(desl1)));

end
