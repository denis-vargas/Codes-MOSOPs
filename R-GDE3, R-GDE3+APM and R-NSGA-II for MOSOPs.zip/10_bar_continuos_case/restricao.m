function v=restricao(n2,QuantRestr3)

v=zeros(1,QuantRestr3);

v(1)=abs(n2(1))/25000-1;
v(2)=abs(n2(2))/25000-1;
v(3)=abs(n2(3))/25000-1;
v(4)=abs(n2(4))/25000-1;
v(5)=abs(n2(5))/25000-1;
v(6)=abs(n2(6))/25000-1;
v(7)=abs(n2(7))/25000-1;
v(8)=abs(n2(8))/25000-1;
v(9)=abs(n2(9))/25000-1;
v(10)=abs(n2(10))/25000-1;


for contv=1:QuantRestr3
    if v(contv)<=0          
        v(contv)=0;
    end    
end

end
