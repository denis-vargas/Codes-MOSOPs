function [FAC,INFAC]=faceinfac(Popla)

limites;
FAC=[];
INFAC=[];
for CPopla=1:size(Popla,1)
    if isequal(Popla(CPopla,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr),zeros(1,QuantRestr))==1
        FAC=[FAC;Popla(CPopla,:)];
    else
        INFAC=[INFAC;Popla(CPopla,:)];
    end
end
clear CPopla Popla; 
end
