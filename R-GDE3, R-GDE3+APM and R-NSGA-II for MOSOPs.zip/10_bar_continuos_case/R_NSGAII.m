tic
clear all
format long
clc
contarodada=1;
limites;

%tic
while contarodada<=NumExec
rand('state',contarodada);

% Principal 
clc

% Par�mentros Iniciais

limites;
NumGeracoes=1;
ContaFilhos=1;
for NumPopIni=1:TamanhoPopulacao
    for NumDimEspa=1:DimEspa
        Populacao(NumPopIni,NumDimEspa)=LimInf(1,NumDimEspa)+rand()*...
            (LimSup(1,NumDimEspa)-LimInf(1,NumDimEspa));
    end
end
zeroscompara=zeros(1,QuantRestr);
ArquExt=[];

ArqInput_C;
for i33=1:TamanhoPopulacao
    area{i33}=Populacao(i33,:);
    [Desl2{i33},Tens{i33}]=Trelica_3d(nBarras,area{i33},numNodes,numColnodesCoord,nodesCoordVetor,...
        CVetor,nodesC,nodesL,numConst,elasticity);    
    Desl{i33}=trans_vet_mat(Desl2{i33},numNodes);
end
clear area Desl2;

% Calculando Fun��o da Popula��o
clear i;
Populacao222=Populacao;
for i=1:TamanhoPopulacao    
    Populacao22a(i,:)=funcpop(Populacao222(i,:),Desl{i});
end
Populacao=[Populacao222 Populacao22a];
clear Populacao222 Populacao22a; 

% Calculando as Viola��es das Restri��es pela Popula��o

clear i;
for i=1:TamanhoPopulacao
    Populacao(i,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))=restricao(Tens{i},QuantRestr);
end

% Iniciando a Evolu��o da Popula��o
while (NumGeracoes<=NumMaxGeracoes) 

clear filhos22; 
for ContaFilhos=1:TamanhoPopulacao
    if mod(ContaFilhos,2)==1
        [filhos22{ContaFilhos},filhos22{ContaFilhos+1}]=FazFil(Populacao);    
    end
end

for ContaFilhos=1:length(filhos22)
    Populacao=[Populacao;filhos22{ContaFilhos}];    
end
GuardaPop=Populacao;
Populacao=excluieleig(Populacao);

[FAC,INFAC]=faceinfac(Populacao);
if isempty(FAC)==0 & isempty(INFAC)==0
    FAC = NDSM(FAC, NumFO, DimEspa);
    for cinfac=1:size(INFAC,1)
        INFAC_2(cinfac,1:NumFO+DimEspa)=INFAC(cinfac,1:NumFO+DimEspa);
        INFAC_2(cinfac,NumFO+DimEspa+1)=sum(INFAC(cinfac,NumFO+DimEspa+1:NumFO+DimEspa+QuantRestr));                
    end
    clear INFAC;
    INFAC=INFAC_2;
    clear INFAC_2;
    INFAC=sortrows(INFAC,NumFO+DimEspa+1);
    for cinfac=1:size(INFAC,1)
        INFAC(cinfac,NumFO+DimEspa+1)=FAC(size(FAC,1),NumFO+DimEspa+1)+cinfac;
        INFAC(cinfac,NumFO+DimEspa+2)=Inf;
    end
    Populacao=RC2([FAC;INFAC], NumFO, DimEspa, TamanhoPopulacao,PRef,epsi_met);
else
    if isempty(FAC)==0
        FAC = NDSM(FAC, NumFO, DimEspa);
        Populacao=RC2(FAC, NumFO, DimEspa, TamanhoPopulacao,PRef,epsi_met);
    else
        for cinfac=1:size(INFAC,1)
            INFAC_2(cinfac,1:NumFO+DimEspa)=INFAC(cinfac,1:NumFO+DimEspa);
            INFAC_2(cinfac,NumFO+DimEspa+1)=sum(INFAC(cinfac,NumFO+DimEspa+1:NumFO+DimEspa+QuantRestr));                
        end
        clear INFAC;
        INFAC=INFAC_2;
        clear INFAC_2;
        INFAC=sortrows(INFAC,NumFO+DimEspa+1);
        for cinfac=1:size(INFAC,1)
            INFAC(cinfac,NumFO+DimEspa+1)=cinfac;
            INFAC(cinfac,NumFO+DimEspa+2)=Inf;
        end
        Populacao=RC2(INFAC, NumFO, DimEspa, TamanhoPopulacao,PRef,epsi_met);
    end
end

% Volta com valores originais das fun��es
Populacao(:,(DimEspa+NumFO+1):(DimEspa+NumFO+2))=[];

for i=1:TamanhoPopulacao
    LinhCar=verquallin(Populacao(i,1:DimEspa),GuardaPop(:,1:DimEspa));
    PopulacaoLinhCar(i,:)=GuardaPop(LinhCar,:);
end

Populacao=[];
Populacao=PopulacaoLinhCar;
clear PopulacaoLinhCar;

%ATUALIZA ARQUIVO EXTERNO

% pega fact�veis da Popula��o
PopulacaoFac=[];
CPF1=1;
for i=1:TamanhoPopulacao
    if isequal(Populacao(i,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr), zeros(1,QuantRestr))==1;
        PopulacaoFac(CPF1,:)=Populacao(i,1:DimEspa+NumFO);
        CPF1=CPF1+1;
    end
end
%FIM DE pega fact�veis da Popula��o

if isempty(PopulacaoFac)==0

ArquExt=[ArquExt;PopulacaoFac];
if isempty(ArquExt)==0
CArquExt1=ArquExt(:,DimEspa+1);
CArquExt2=ArquExt(:,DimEspa+2);
ParetoFr=paretofront([CArquExt1 CArquExt2]);
ArquExt=excluieleig(ArquExt(ParetoFr,:));
end

end

% Atualiza Populacao e Gera��o
ContaFilhos=1;
clc
fprintf('\n');
fprintf('R-NSGA-II\n');
fprintf('Execucao %d\n',contarodada);
fprintf('Geracao %d\n',NumGeracoes);
NumGeracoes=NumGeracoes+1;

clear LinhCar                   Selecaovet3               mediaaptsom      ArquExt1...                  
      NumDimEspa                Selecaovetalvo            mediaviolacao    ArquExt2...
      mediaviolacaoquad         ArquExt3                  opcoesdeescolha  CPF1...
      contavetexp               sd2mediaviolacao1         ConjuntoParetoOtimoTotal  erre...
      somaviolacao              vet1                      filhos                    vet2...                      
      PopulacaoFac              vet3                      i                         vetalvo...
      idlim                     vetexper                  Selecaovet1               jh...
      vetordoad                 Selecaovet2               mediaapt                  GuardaPop...
      FAC INFAC filhos22; 
      

end

CArquExt1=ArquExt(:,DimEspa+1);
CArquExt2=ArquExt(:,DimEspa+2);
ParetoFr=paretofront([CArquExt1 CArquExt2]);
ArquExt2=[];
ArquExt2=ArquExt(ParetoFr,:);
clear ArquExt;
ArquExt=ArquExt2;
clear ArquExt2;
Rodada{contarodada}=[ArquExt(:,1:DimEspa) ArquExt(:,DimEspa+1:DimEspa+NumFO)];
Rodada{contarodada}=excluieleig(Rodada{contarodada});
contarodada=contarodada+1;
clear Populacao ArquExt;
clear CArquExt1 CArquExt2 ParetoFr;

end

resultados=strcat('R_NSGA2.mat');
save(resultados,'Rodada');
toc