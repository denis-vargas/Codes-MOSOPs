function resultado2=verquallin(Vetdado1,MatrizDada1)

[lmdada1,cmdada1]=size(MatrizDada1);

resultado2=0;

for NumelMatrDada11=1:lmdada1    
        if Vetdado1==MatrizDada1(NumelMatrDada11,:)
            resultado2=NumelMatrDada11;
            break
        end
end
end