nBarras=10;
numNodes=6;
nodesCoordAux=[5    3
            3    1 
            6    4
            4    2
            3    4
            1    2
            5    4
            3    6
            3    2
            1    4];
numColnodesCoord=size(nodesCoordAux,2);
nodesCoordVetor=[];
for cLncv=1:size(nodesCoordAux,1)
    nodesCoordVetor=[nodesCoordVetor nodesCoordAux(cLncv,:)];
end       
nodesC=[0 0 1 0 0 1 0 0 1 0 0 1 1 1 1 1 1 1];
numConst=10;
LinMatAux1=2;
MatAux1=[2    2  -100000.0 
         4    2  -100000.0]; 
nodesL=zeros(1,3*numNodes);
for cLinMatAux1=1:LinMatAux1
    nodesL(MatAux1(cLinMatAux1,1)*3-(3-(MatAux1(cLinMatAux1,2))))=MatAux1(cLinMatAux1,3);
end
Caux=[720.0     360.0       0.0
   720.0       0.0       0.0
   360.0     360.0       0.0
   360.0       0.0       0.0
     0.0     360.0       0.0
     0.0       0.0       0.0];
CVetor=[];
for cLcv=1:size(Caux,1)
    CVetor=[CVetor Caux(cLcv,:)];
end       
elasticity=[10000000.0 10000000.0 10000000.0 10000000.0 10000000.0...
    10000000.0 10000000.0 10000000.0 10000000.0 10000000.0];
