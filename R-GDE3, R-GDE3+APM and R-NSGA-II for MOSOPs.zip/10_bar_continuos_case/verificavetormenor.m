function result10=verificavetormenor(vet22,vet23);

[m1,n1]=size(vet22);
result101=zeros(n1);
result102=zeros(n1);

for containdvet=1:n1
    if  vet22(1,containdvet)<=vet23(1,containdvet)
        
        result101(containdvet)=0;
        
    else
        
        result101(containdvet)=1;
        
    end
    
end

result10=isequal(result101,result102);

end
