function [Co_Ra,Quantos]=Tira_Rank(x,M,V,TamanhoPopulacao)

q_ran=x(TamanhoPopulacao+1,M+V+1);
Co_Ra=[];
for i=1:size(x,1)
    if x(i,M+V+1)==q_ran
        Co_Ra=[Co_Ra;x(i,:)];        
    end    
end
Quantos=1;
while x(Quantos,M+V+1)<q_ran
    Quantos=Quantos+1;
end
Quantos=TamanhoPopulacao-Quantos+1;


