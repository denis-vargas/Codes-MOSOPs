function result101=excluieleig(entrada121)

entrada12=[];
entrada12=sortrows(entrada121,1);
result101=[];


while isempty(entrada12)==0
    Inds=[];
    Inds=find(entrada12(:,1)==entrada12(1,1));
    result101=[result101;excluieleig2(entrada12(Inds,:))];
    entrada12(Inds,:)=[];
end

end