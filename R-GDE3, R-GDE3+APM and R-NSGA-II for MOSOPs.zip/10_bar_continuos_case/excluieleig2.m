function result101=excluieleig2(entrada121)

entrada12=entrada121;
result101=[];

for contlinentrada121=1:size(entrada12,1)
    for contlinentrada122=contlinentrada121:size(entrada12,1)
        if (contlinentrada121~=contlinentrada122) && (isequal(entrada12(contlinentrada121,:),entrada12(contlinentrada122,:))==1)
            entrada12(contlinentrada121,:)=zeros(1,size(entrada12,2));
        end
    end
end

contlinentrada123=1;
contlinentrada124=1;
while contlinentrada123<=size(entrada12,1)
    if isequal(entrada12(contlinentrada123,:),zeros(1,size(entrada12,2)))==0
        result101(contlinentrada124,:)=entrada12(contlinentrada123,:);
        contlinentrada124=contlinentrada124+1;
    end
    contlinentrada123=contlinentrada123+1;
end
if isempty(result101)==1
    result101=zeros(1,size(entrada12,2));
end
end