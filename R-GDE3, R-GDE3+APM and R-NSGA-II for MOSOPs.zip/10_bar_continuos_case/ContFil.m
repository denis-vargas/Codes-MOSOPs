function [vetexper,DeslVE,TensVE]=ContFil(Populacao,ContaFilhos)
limites;


Selecaovet1=0;
Selecaovet2=0;
Selecaovet3=0;
Selecaovetalvo=0;

while isequal(size(excluieleig([Selecaovet1;Selecaovet2;Selecaovet3;Selecaovetalvo]),1),4)==0
opcoesdeescolha=randperm(TamanhoPopulacao);    
Selecaovet1=opcoesdeescolha(1);
Selecaovet2=opcoesdeescolha(2);
Selecaovet3=opcoesdeescolha(3);
Selecaovetalvo=ContaFilhos;    
end

vet1=Populacao(Selecaovet1,1:DimEspa);
vet2=Populacao(Selecaovet2,1:DimEspa);
vet3=Populacao(Selecaovet3,1:DimEspa);
vetalvo=Populacao(Selecaovetalvo,:);

% C�lculo do vetor doador
vetordoad=vet3+F*(vet1-vet2);

% Gerando o vetor experimental
vetexper=[];
vetexper=zeros(1,DimEspa);
jh=floor(DimEspa*rand())+1;
for contavetexp=1:DimEspa
    erre=rand();
    if (erre<ProbCruzamento) || (contavetexp==jh)
        vetexper(1,contavetexp)=vetordoad(1,contavetexp);
    else
        vetexper(1,contavetexp)=vetalvo(1,contavetexp);
    end
end

% Mantendo o vetor experimental dentro do limite

for idlim=1:DimEspa   
    while vetexper(1,idlim)>LimSup(1,idlim)
        vetexper(1,idlim)=LimSup(1,idlim);
    end
    while vetexper(1,idlim)<LimInf(1,idlim)
        vetexper(1,idlim)=LimInf(1,idlim);
    end
end

% Comparando com o Vetor Alvo

ArqInput_C;
area=vetexper;
[Desl2,TensVE]=Trelica_3d(nBarras,area,numNodes,numColnodesCoord,nodesCoordVetor,...
CVetor,nodesC,nodesL,numConst,elasticity);    
DeslVE=trans_vet_mat(Desl2,numNodes);
clear area Desl2;

vetexper(:,DimEspa+1:DimEspa+NumFO)=funcpop(vetexper,DeslVE);

% Calculando as Viola��es do Vetor Experimental
vetexper(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))=restricao(TensVE,QuantRestr);

