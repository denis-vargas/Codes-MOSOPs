function result101=trans_vet_mat(entrada121,numNodes)

result101=[];
for cN_no=0:(numNodes-1)
    result101=[result101;entrada121(cN_no*3+1) entrada121(cN_no*3+2) entrada121(cN_no*3+3)];
end
