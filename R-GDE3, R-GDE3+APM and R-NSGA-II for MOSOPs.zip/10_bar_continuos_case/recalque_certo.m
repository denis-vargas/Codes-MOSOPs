function [Ele_Ent,x,Reserva2]=recalque_certo(x,M,V,PRef,epsi_met,MaioX,MenoX)


for cDis=1:size(x,1)
    D2(cDis)=sqrt(sum(1/M*(((x(cDis,V+1:V+M)-PRef)./(MaioX-MenoX)).^2)));
end
j=find(D2==min(D2));
while length(j)>1    
    j(length(j))=[];
end
ACDis=j;
for cDis=1:size(x,1)
    clear D2a;
    D2a=sum(abs(((x(j,V+1:V+M)-x(cDis,V+1:V+M))./(MaioX-MenoX))));
	if (D2a<=epsi_met) && (cDis~=j)
        ACDis=[ACDis cDis];
	end
end
Reserva2=[];
if (isempty(ACDis)==0) & (length(ACDis)>1)
    Pos_Esc=randperm(length(ACDis));
    Ele_Ent=x(ACDis(Pos_Esc(1)),:);
    Reserva=[];    
    for cDis=1:size(x,1)        
        if isempty(find(ACDis==cDis))==1
            Reserva=[Reserva;x(cDis,:)];
        elseif cDis~=ACDis(Pos_Esc(1))
            Reserva2=[Reserva2;x(cDis,:)];                        
        end            
    end    
    if isempty(Reserva)==0
        x=[];
        x=Reserva;        
    else
        x(ACDis(Pos_Esc(1)),:)=[];
    end    
else
    Ele_Ent=x(j,:);
    x(j,:)=[];    
end
if isequal(x,Reserva2)==1
    x=[];
end

