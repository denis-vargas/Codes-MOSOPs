function [Fil1,Fil2]=FazFil(Populacao)

limites;

Selecaovet1=0;
Selecaovet2=0;
Selecaovet3=0;
Selecaovet4=0;

while isequal(size(excluieleig([Selecaovet1;Selecaovet2;Selecaovet3;Selecaovet4]),1),4)==0
opcoesdeescolha=randperm(TamanhoPopulacao);    
Selecaovet1=opcoesdeescolha(1);
Selecaovet2=opcoesdeescolha(2);
Selecaovet3=opcoesdeescolha(3);
Selecaovet4=opcoesdeescolha(4);
end

vet1=Populacao(Selecaovet1,:);
vet2=Populacao(Selecaovet2,:);
vet3=Populacao(Selecaovet3,:);
vet4=Populacao(Selecaovet4,:);

% Torneio Bin�rio
clear FAC INFAC Pai1;
[FAC,INFAC]=faceinfac([vet1;vet2]);
if isempty(FAC)==0 && isempty(INFAC)==0
    Pai1=FAC(:,1:DimEspa);    
else
    if isempty(FAC)==0
        Pai1=[1 vet1(:,DimEspa+1:DimEspa+NumFO);2 vet2(:,DimEspa+1:DimEspa+NumFO)];
        Pai1=RC(NDSM(Pai1, NumFO,1),NumFO, 1, 1);
        if Pai1(:,1)==1
            clear Pai1;
            Pai1=vet1(:,1:DimEspa);
        else
            clear Pai1;
            Pai1=vet2(:,1:DimEspa);
        end
    else
        Viol1=sum(vet1(:,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr));
        Viol2=sum(vet2(:,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr));
        if Viol1<=Viol2;
            clear Pai1;
            Pai1=vet1(:,1:DimEspa);
        else
            clear Pai1;
            Pai1=vet2(:,1:DimEspa);
        end        
    end
end

clear FAC INFAC Pai2;
[FAC,INFAC]=faceinfac([vet3;vet4]);
if isempty(FAC)==0 && isempty(INFAC)==0
    Pai2=FAC(:,1:DimEspa);    
else
    if isempty(FAC)==0
        Pai2=[3 vet3(:,DimEspa+1:DimEspa+NumFO);4 vet4(:,DimEspa+1:DimEspa+NumFO)];
        Pai2=RC(NDSM(Pai2, NumFO,1),NumFO, 1, 1);
        if Pai2(:,1)==3
            clear Pai2;
            Pai2=vet3(:,1:DimEspa);
        else
            clear Pai2;
            Pai2=vet4(:,1:DimEspa);
        end
    else
        Viol3=sum(vet3(:,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr));
        Viol4=sum(vet4(:,DimEspa+NumFO+1:DimEspa+NumFO+QuantRestr));
        if Viol3<=Viol4;            
            clear Pai2;
            Pai2=vet3(:,1:DimEspa);
        else
            clear Pai2;
            Pai2=vet4(:,1:DimEspa);
        end        
    end
end



if rand()<=ProbCruzamento
    % Initialize the children to be null vector.
    clear parent_1 parent_2 u j bq r1 r2 delta1 delta2 child_1 child_2; 
    child_1 = [];
    child_2 = [];    
    parent_1 = Pai1;
    parent_2 = Pai2;
    % Perform corssover for each decision variable in the chromosome.
    for j = 1 : DimEspa
        u(j) = rand(1);
        if u(j) <= 0.5
            bq(j) = (2*u(j))^(1/(muc+1));
        else
            bq(j) = (1/(2*(1 - u(j))))^(1/(muc+1));
        end
        % Generate the jth element of first child
        child_1(j) = ...
            0.5*(((1 + bq(j))*parent_1(j)) + (1 - bq(j))*parent_2(j));
        % Generate the jth element of second child
        child_2(j) = ...
            0.5*(((1 - bq(j))*parent_1(j)) + (1 + bq(j))*parent_2(j));        
    end
        
    Fil1=child_1;
    Fil2=child_2;
       
    %Mantendo os filhos dentro do limite

    for idlim=1:DimEspa   
        while Fil1(1,idlim)>LimSup(1,idlim)
            Fil1(1,idlim)=LimSup(1,idlim);
        end
        while Fil1(1,idlim)<LimInf(1,idlim)
            Fil1(1,idlim)=LimInf(1,idlim);
        end
    end

    for idlim=1:DimEspa   
        while Fil2(1,idlim)>LimSup(1,idlim)
            Fil2(1,idlim)=LimSup(1,idlim);
        end
        while Fil2(1,idlim)<LimInf(1,idlim)
            Fil2(1,idlim)=LimInf(1,idlim);
        end
    end            
    
else    
    if Pai1==vet1(:,1:DimEspa)
        clear Fil1;
        Fil1=vet1(:,1:DimEspa);
    else
        clear Fil1;
        Fil1=vet2(:,1:DimEspa);
    end
    if Pai2==vet3(:,1:DimEspa)
        clear Fil2;
        Fil2=vet3(:,1:DimEspa);
    else
        clear Fil2;
        Fil2=vet4(:,1:DimEspa);
    end    
end



for idlim=1:DimEspa   
    if rand()<1/DimEspa
        r1=rand(1);
        if r1 < 0.5
            delta1 = (2*r1)^(1/(mum+1)) - 1;                
        else
            delta1 = 1 - (2*(1 - r1))^(1/(mum+1));
        end
        Fil1(1,idlim) = Fil1(1,idlim) + delta1;
        while Fil1(1,idlim)>LimSup(1,idlim)
            Fil1(1,idlim)=LimSup(1,idlim);
        end
        while Fil1(1,idlim)<LimInf(1,idlim)
            Fil1(1,idlim)=LimInf(1,idlim);
        end                
    end
    if rand()<1/DimEspa
        r1=rand(1);
        if r1 < 0.5
            delta1 = (2*r1)^(1/(mum+1)) - 1;                
        else
            delta1 = 1 - (2*(1 - r1))^(1/(mum+1));
        end
        Fil2(1,idlim) = Fil2(1,idlim) + delta1;
        while Fil2(1,idlim)>LimSup(1,idlim)
            Fil2(1,idlim)=LimSup(1,idlim);
        end
        while Fil2(1,idlim)<LimInf(1,idlim)
            Fil2(1,idlim)=LimInf(1,idlim);
        end                
    end
end            

% Calculando Fun��o Objetivo e Viola��o

ArqInput_C;
area=Fil1;
[Desl2,TensVE1]=Trelica_3d(nBarras,area,numNodes,numColnodesCoord,nodesCoordVetor,...
CVetor,nodesC,nodesL,numConst,elasticity);    
DeslVE1=trans_vet_mat(Desl2,numNodes);
clear area Desl2;

Fil1(:,DimEspa+1:DimEspa+NumFO)=funcpop(Fil1,DeslVE1);
Fil1(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))=restricao(TensVE1,QuantRestr);

ArqInput_C;
area=Fil2;
[Desl2,TensVE2]=Trelica_3d(nBarras,area,numNodes,numColnodesCoord,nodesCoordVetor,...
CVetor,nodesC,nodesL,numConst,elasticity);    
DeslVE2=trans_vet_mat(Desl2,numNodes);
clear area Desl2;

Fil2(:,DimEspa+1:DimEspa+NumFO)=funcpop(Fil2,DeslVE2);
Fil2(:,(DimEspa+NumFO+1):(DimEspa+NumFO+QuantRestr))=restricao(TensVE2,QuantRestr);


